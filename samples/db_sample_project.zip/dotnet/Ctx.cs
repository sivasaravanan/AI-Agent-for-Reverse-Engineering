using Microsoft.EntityFrameworkCore;
public class ShopCtx : DbContext {
  public DbSet<Order> Orders { get; set; }
  protected override void OnConfiguring(DbContextOptionsBuilder b) => b.UseSqlServer(cs);
}
