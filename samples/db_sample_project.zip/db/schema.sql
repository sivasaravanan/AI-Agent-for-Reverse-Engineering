-- comment mentioning mysql only
CREATE TABLE orders (
  id INT IDENTITY(1,1) PRIMARY KEY,
  customer_id INT REFERENCES customers(id),
  title NVARCHAR(100)
);
GO
