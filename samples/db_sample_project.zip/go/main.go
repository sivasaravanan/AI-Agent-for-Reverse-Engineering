package main
import _ "github.com/lib/pq"
func main(){ sql.Open("postgres", "x") }
