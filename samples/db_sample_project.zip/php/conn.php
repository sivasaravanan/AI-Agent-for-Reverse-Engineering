<?php $p = new PDO('mysql:host=h1.corp.local;dbname=blog', 'bloguser', 'pw2');
