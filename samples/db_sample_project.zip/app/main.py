import psycopg2
from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import declarative_base
Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    name = Column(String)

DSN = 'postgresql://appuser:SuperSecret123@db.internal.corp:5432/shop'
def get(uid, cur):
    cur.execute(f"SELECT * FROM users WHERE id={uid}")
