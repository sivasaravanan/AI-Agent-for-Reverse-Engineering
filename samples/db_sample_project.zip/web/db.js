const mysql = require('mysql2');
const m = require('mongoose');
const Cat = mongoose.model('Cat', new Schema({n:String}));
mysql.createConnection('mysql://shop:pw1@mysql.internal.corp:3306/catalog');
