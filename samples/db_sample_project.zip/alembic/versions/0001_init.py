def upgrade():
    op.create_table('users', sa.Column('id'))
