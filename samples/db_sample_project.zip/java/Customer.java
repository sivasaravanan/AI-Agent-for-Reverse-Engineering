import javax.persistence.*;
@Entity
@Table(name = "customers")
public class Customer {}
